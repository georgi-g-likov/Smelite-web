package com.smelite.entity;

public enum Role {
    MASTER,
    APPRENTICE
}
