
package com.smelite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmeliteApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmeliteApplication.class, args);
    }
}
